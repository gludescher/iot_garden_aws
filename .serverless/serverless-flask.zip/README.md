# iot_garden_aws
Smart garden with IoT Services integration

## AWS
This is the repo for AWS integration.
It uses:
- Python Serverless Framework for dealing with AWS Lambda
- DynamoDB for data persistance
With this, we created a RESTful API with cloud data storage, allowing a mobile app to fetch this data.
